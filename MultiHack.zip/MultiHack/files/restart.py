import os
import time
time.sleep(2)
os.system('start Multihack.py')