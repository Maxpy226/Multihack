THIS TOOL IS ONLY MADE FOR EDUCATIONAL PURPOSES ONLY.

Skid hacking tool

Multihack Release Alpha 1.0 by Maxpy226 and EpicNori. 


Instructions:

How to use the Ip logger:

You need a discord account.

Go to discord (app or website)

Make a server, select a channel in the server and go to channel settings. Then go to Integrations, then webhooks. Make a Webhook then copy its url. Note: Make the server Private ASAP. You don't want the logged ips exposed.



Use the Prepare Ip logger function in Multihack to auto copy the logger and config file to the multi hack folder. You can get there by selecting "Hacks" in the menu.

Then go into the loggersettings.json file and copy the webhook url into the URL key.

Now it's ready.

If the logger is executed, it sends the Ip and hostname into the channel.

How to use PySpam:

Go to the configs folder in the MultiHack folder and configure it to your liking.

Pyspam will auto open whatsapp web, but you can use it for any chat.
But remember ITS FOR EDUCATIONAL PURPOSES ONLY. DO NOT ACTUALLY SPAM SOMEONE FULL.


For more guidelines, see the Guidelines.md file.

This is the open source zip version, so you need to run the RUNBEFOREUSE.bat file at least once. Exe format with Installers will be coming soon.


How to use PMP:

Go into Multihack and go to Chat room (PMP).

Server Instructions:

Press start PMP server to make a server for the chatroom.

Then input the name for the server.

This only needs to be done on one computer that is the server.

Client Instructions:

Press start PMP client.

Then it will show you the available PMP servers on the network. 

After you choose the one you want, enter your username, and now you can start chatting. Type /dm <username> <message> to send private dms. Type /ou to show online users.

When you first launch PMP (chat room) it could give you a security pop-up because it needs to open ports.

Note that this only works if the devices are on the same network.